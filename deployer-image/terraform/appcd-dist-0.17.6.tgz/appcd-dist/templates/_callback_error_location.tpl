{{/*
Inline /callback-error in master ingress server-snippets.
- Maintain readable HTML in files/callback-error/index.html.
- Helm minifies before base64 so the nginx return line stays under size limits.
- Ingress splits snippets on ";" — loader body has no semicolons.
- Outer return uses single quotes; atob("...") uses double quotes inside.
*/}}
{{- define "appcd.callbackErrorPage.location" -}}
{{- $html := .Files.Get "files/callback-error/index.html" | replace "\n" " " | replace "\r" "" | replace "  " " " | replace "  " " " | replace "  " " " | trim -}}
{{- $htmlB64 := $html | b64enc -}}
{{- $loader := printf "<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content=\"width=device-width,initial-scale=1\"><title>Sign-in error | StackGen</title></head><body><script>document.write(atob(\"%s\"))</script></body></html>" $htmlB64 -}}
location = /callback-error {
  default_type text/html;
  add_header Cache-Control "no-store" always;
  return 200 '{{ $loader }}';
}
{{- end -}}
