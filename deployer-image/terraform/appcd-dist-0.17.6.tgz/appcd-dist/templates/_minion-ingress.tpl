{{- define "appcd.minion-ingress" -}}
{{- $ingress := .ingress -}}
{{- $root := .root -}}
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ $ingress.name }}
  namespace: {{ $root.Values.namespace }}
  labels:
    {{- include "appcd.selectorLabels" $root | nindent 4 }}
    app.kubernetes.io/name: {{ $ingress.service }}
  annotations:
    nginx.org/mergeable-ingress-type: minion
    {{- if $ingress.additionalAnnotations }}
    {{- toYaml $ingress.additionalAnnotations | nindent 4 }}
    {{- end }}
    nginx.org/location-snippets: |
      {{- if not $ingress.skipAuth }}
      auth_request /auth;
      auth_request_set $login $upstream_http_x_appcd_login;
      proxy_set_header X-Appcd-Login $login;
      auth_request_set $principal_name $upstream_http_x_stackgen_principal;
      proxy_set_header X-Stackgen-Principal $principal_name;
      auth_request_set $appcd_org $upstream_http_x_appcd_org;
      proxy_set_header X-Appcd-Org $appcd_org;
      auth_request_set $appcd_scopes $upstream_http_x_appcd_scopes;
      proxy_set_header X-Appcd-Scopes $appcd_scopes;
      auth_request_set $stackgen_tenant_identifier $upstream_http_x_stackgen_tenant_identifier;
      proxy_set_header X-Stackgen-Tenant-Identifier $stackgen_tenant_identifier;
      auth_request_set $stackgen_tenant $upstream_http_x_stackgen_tenant;
      proxy_set_header X-Stackgen-Tenant $stackgen_tenant;
      auth_request_set $appcd_session $upstream_http_x_appcd_session;
      proxy_set_header X-Appcd-Session $appcd_session;
      auth_request_set $session_type $upstream_http_x_appcd_session_type;
      proxy_set_header X-Appcd-Session-Type $session_type;
      {{- end }}
      {{- if $ingress.rewrite }}
      rewrite {{ $ingress.rewrite }} break;
      {{- end }}
      {{- if $ingress.additionalSnippets }}
      {{- range $snippet := $ingress.additionalSnippets }}
      {{ $snippet | nindent 6 }}
      {{- end }}
      {{- end }}
spec:
  ingressClassName: {{ $root.Values.global.ingressClassName | default "nginx" }}
  rules:
  - host: {{ $root.Values.domain }}
    http:
      paths:
      - path: {{ $ingress.path }}
        pathType: {{ $ingress.pathType | default "Prefix" }}
        backend:
          service:
            name: {{ $ingress.service }}
            port:
              number: {{ $ingress.port }}
---
{{- end -}}
