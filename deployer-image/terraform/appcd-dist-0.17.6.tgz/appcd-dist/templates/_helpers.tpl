{{/*
Expand the name of the chart.
*/}}
{{- define "appcd-dist.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "appcd-dist.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "appcd-dist.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "appcd-dist.labels" -}}
helm.sh/chart: {{ include "appcd-dist.chart" . }}
{{ include "appcd-dist.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "appcd-dist.selectorLabels" -}}
app.kubernetes.io/name: {{ include "appcd-dist.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "appcd-dist.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "appcd-dist.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return "true" or "false" for whether a minion ingress entry should be rendered.
- enable: false — hard disable
- enableWhen: dot-path into Values (e.g. features.guild) — gate on a flag
- enableWhenAll: list of dot-paths — all must be true
- enableWhenAppcdUiDisabled: true — render when appcd-ui.enabled is false
- enableWhenAppcdUiEnabled: true — render when appcd-ui.enabled is true
- Multiple gate fields combine with AND; default is enabled when none are set
*/}}
{{- define "appcd.ingress.enabled" -}}
{{- $ingress := .ingress -}}
{{- $root := .root -}}
{{- if eq $ingress.enable false -}}
false
{{- else -}}
{{- $enabled := true -}}
{{- if $ingress.enableWhenAll -}}
{{- range $path := $ingress.enableWhenAll -}}
{{- if $enabled -}}
{{- $val := $root.Values -}}
{{- range splitList "." $path -}}
{{- $val = index $val . -}}
{{- end -}}
{{- if not $val -}}{{- $enabled = false -}}{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if and $enabled $ingress.enableWhen -}}
{{- $val := $root.Values -}}
{{- range splitList "." $ingress.enableWhen -}}
{{- $val = index $val . -}}
{{- end -}}
{{- if not $val -}}{{- $enabled = false -}}{{- end -}}
{{- end -}}
{{- if and $enabled $ingress.enableWhenAppcdUiDisabled -}}
{{- if not (eq (index $root.Values "appcd-ui" "enabled") false) -}}
{{- $enabled = false -}}
{{- end -}}
{{- end -}}
{{- if and $enabled $ingress.enableWhenAppcdUiEnabled -}}
{{- if not (eq (index $root.Values "appcd-ui" "enabled") true) -}}
{{- $enabled = false -}}
{{- end -}}
{{- end -}}
{{- ternary "true" "false" $enabled -}}
{{- end -}}
{{- end -}}

{{/*
Return "true" or "false" for whether a platform ExternalSecret should be rendered.
Set ops.externalSecrets.<name>: false when the AWS SM property is absent in an env.
Defaults to true when unset.
*/}}
{{/*
Return whether appcd-ui is deployed (true only when appcd-ui.enabled is explicitly true).
Exposed as features.json stackgenCore for Guild product switcher visibility.
*/}}
{{- define "appcd.appcdUi.enabled" -}}
{{- eq (index .Values "appcd-ui" "enabled") true -}}
{{- end -}}

{{/*
Resolve features.rootRedirect to an absolute path for bare-domain "/" redirect.
Supported values: core|sre|chat|aiden|devops (default core = no redirect).
Legacy features.rootRedirectToSre: true maps to sre when rootRedirect is unset/core.
Returns empty string when redirect should not be emitted.
Paths must keep their trailing slash: the app upstreams listen on 8080 and answer
a slash-less path with an absolute 301 that leaks http://$host:8080/ to the browser.
*/}}
{{- define "appcd.rootRedirect.path" -}}
{{- $target := .Values.features.rootRedirect | default "core" -}}
{{- if and (or (eq $target "core") (eq $target "")) .Values.features.rootRedirectToSre -}}
{{- $target = "sre" -}}
{{- end -}}
{{- if or (eq $target "core") (eq $target "") -}}
{{- else if and (eq $target "sre") .Values.features.guild .Values.features.aiosApps.sreCopilot -}}
/app/sre/
{{- else if and (eq $target "chat") .Values.features.guild -}}
/app/settings/
{{- else if and (eq $target "aiden") .Values.features.aiden -}}
/ai/
{{- else if and (eq $target "devops") .Values.features.guild .Values.features.aiosApps.devops -}}
/app/devops/
{{- end -}}
{{- end -}}

{{/*
Inline /callback-error page in master ingress when appcd-ui is off.
*/}}
{{- define "appcd.callbackErrorPage.enabled" -}}
{{- if eq (.Values.callbackErrorPage.enabled | default true) false -}}
false
{{- else if not (eq (index .Values "appcd-ui" "enabled") false) -}}
false
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
Postgres sslmode for every DSN this chart renders. Defined here in the umbrella
chart and also called from the file:// subcharts (appcd, iac-gen,
infra-catalog-tracker), which see it through Helm's shared template namespace.
*/}}
{{- define "appcd.database.sslMode" -}}
{{- $mode := dig "database" "sslMode" "disable" (.Values.global | default dict) -}}
{{- if not (has $mode (list "disable" "allow" "prefer" "require" "verify-ca" "verify-full")) -}}
{{- fail (printf "global.database.sslMode: %q is not a libpq sslmode (disable|allow|prefer|require|verify-ca|verify-full)" $mode) -}}
{{- end -}}
{{- $mode -}}
{{- end -}}

{{- define "appcd.envSecretArn" -}}
{{- .Values.ops.envSecretArn | default .Values.ops.platformSecretArn -}}
{{- end -}}

{{- define "appcd.externalSecret.enabled" -}}
{{- $name := .name -}}
{{- $root := .root -}}
{{- $cfg := $root.Values.ops.externalSecrets | default dict -}}
{{- if hasKey $cfg $name -}}
{{- ternary "true" "false" (index $cfg $name) -}}
{{- else -}}
true
{{- end -}}
{{- end -}}
