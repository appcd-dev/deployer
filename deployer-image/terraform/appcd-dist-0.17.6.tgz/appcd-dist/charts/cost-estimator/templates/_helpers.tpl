{{- define "cost-estimator.name" -}}
cost-estimator
{{- end -}}

{{- define "cost-estimator.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride -}}
{{- else if .Values.nameOverride -}}
{{- .Values.nameOverride -}}
{{- else -}}
{{- .Release.Name -}}-{{- include "cost-estimator.name" . -}}
{{- end -}}
{{- end -}}

{{- define "cost-estimator.labels" -}}
app.kubernetes.io/name: {{ include "cost-estimator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | default "latest" }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "cost-estimator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cost-estimator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "cost-estimator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- if .Values.serviceAccount.name -}}
{{- .Values.serviceAccount.name -}}
{{- else -}}
{{- include "cost-estimator.fullname" . -}}
{{- end -}}
{{- else -}}
default
{{- end -}}
{{- end -}}
