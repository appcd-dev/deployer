# aios-apps Helm chart

Deploys one AIOS application container and optionally publishes a discovery catalog entry for Guild.

## Install modes

### 1. Helm alias (recommended in appcd-dist)

Each app is a **separate chart dependency** with its own lifecycle:

```yaml
# appcd-dist/Chart.yaml
dependencies:
  - name: aios-apps
    alias: sre-copilot
    condition: features.aiosApps.sreCopilot
    version: 0.2.1

# appcd-dist/values.yaml
aiosAppAliases:
  - sre-copilot

sre-copilot:
  enabled: true
  catalog:
    create: false   # parent builds appcd-aios-apps-catalog
  endpoint: "http://appcd-sre-copilot-ui:8080"
  image:
    repository: ghcr.io/appcd-dev/stackgen-sre-app
    tag: "0.0.2"
```

Add another app: new `alias` in `Chart.yaml`, name in `aiosAppAliases`, values block, and `features.aiosApps.<camelCase>: true`.

Guild mounts the merged catalog from appcd-dist (`{{ .Release.Name }}-aios-apps-catalog`).

### 2. Multi-app map (direct chart install)

One release, several apps under `apps.<name>`:

```yaml
apps:
  sre-copilot:
    enabled: true
    endpoint: "http://my-release-sre-copilot-ui:8080"
    image: { repository: "...", tag: "1.0.0" }
```

## Wire catalog into Guild

```yaml
stackgen-guild:
  guild:
    appsCatalog:
      enabled: true
      configMapName: appcd-aios-apps-catalog
```

## Rolling deployments

Kubernetes only restarts pods when the Deployment pod template changes. A floating tag such as `main` does not change the manifest, so new images are not picked up unless something else in the template changes.

This chart follows the same pattern as `stackgen-guild`:

| Mechanism | Values | Effect |
|-----------|--------|--------|
| Rolling update | `defaults.strategy` (default `maxUnavailable: 0`, `maxSurge: 1`) | Keeps at least one pod ready during deploys when `replicas` > 1 |
| Catalog checksum | `catalog.create: true` (default) | Changing `endpoint` or app list updates `checksum/catalog` and rolls pods |
| Force restart | `ops.forceRestart: true` | Adds a random `rollme` annotation on each `helm upgrade` to roll pods even when `image.tag` is unchanged |

For appcd-alpha (or any env using a floating `main` tag), set `ops.forceRestart: true` in the release values used by CI/CD on each deploy.

```yaml
ops:
  forceRestart: true
```

## Values reference (single-app / alias)

| Field | Description |
|-------|-------------|
| `ops.forceRestart` | Force pod rollout on every helm upgrade (floating tags) |
| `defaults.strategy` | Deployment rolling update strategy (default zero-downtime) |
| `enabled` | Deploy this app |
| `endpoint` | Discovery URL in apps.yaml |
| `catalog.create` | Per-alias ConfigMap (false when parent merges) |
| `defaults.guildHostAddr` | Injected as `GUILD_HOST_ADDR` |
| `defaults.replicas` | Deployment replica count when app omits `replicas` (default `1`) |
| `defaults.metricsPort` | Prometheus scrape port (`METRICS_PORT`, default `9091`) |
| `defaults.serviceMonitor` | Prometheus Operator ServiceMonitor defaults (`enabled`, `interval`, `path`) |
| `serviceMonitor` | Per-app ServiceMonitor override (e.g. `enabled: true`) |
| `image` | Container image |
| `env` / `envFromSecretKeys` / `envFromSecrets` | Credentials |

## Metrics (Prometheus)

AIOS app containers use [go-lib/metrics](https://github.com/appcd-dev/go-lib): OpenTelemetry counters export to **`GET /metrics`** on a **dedicated port** (not the HTTP API port).

| Setting | Default | K8s wiring |
|---------|---------|------------|
| `METRICS_PORT` | `9091` | Container port `metrics`; Service port `metrics` |
| `SERVICE_NAME` | Helm app name (e.g. `sre-copilot`) | OTel `service.name` on exported series |
| ServiceMonitor | `defaults.serviceMonitor.enabled` (`false`) | Scrapes Service port `metrics`, path `/metrics` |

Enable scraping in appcd-dist (example for SRE Copilot):

```yaml
sre-copilot:
  serviceMonitor:
    enabled: true
```

When `serviceMonitor.enabled` is true, the chart also sets `prometheus.io/scrape`, `prometheus.io/port`, and `prometheus.io/path` on the app **Service** (same pattern as `stackgen-guild`). StackGen Observe uses **vmagent** service discovery on those annotations; a ServiceMonitor CRD alone is not enough for Observe Grafana.

The SRE app (`stackgen-sre-app`) exposes domain counters such as `api_request_total{operation}`, `alert_sync_completed`, `investigation_started`, and semantic errors via the shared `errors_total{err,code}` counter from `metrics.RecordError`.

## Resource names (alias `sre-copilot`, release `appcd`)

| Resource | Name |
|----------|------|
| Deployment | `appcd-sre-copilot` |
| Service | `appcd-sre-copilot-ui` |
| Catalog (parent) | `appcd-aios-apps-catalog` |
