{{/* Renders Deployment + Service for one app. Expects dict: root, name, app */}}
{{- define "aios-apps.deploymentApp" -}}
{{- $root := .root }}
{{- $appName := .name }}
{{- $app := .app }}
{{- $singleApp := include "aios-apps.isSingleApp" $root | eq "true" }}
{{- $ctx := dict "name" $appName "appName" $appName "Release" $root.Release "Chart" $root.Chart "singleApp" $singleApp }}
{{- $metricsPort := $app.metricsPort | default $root.Values.defaults.metricsPort | default 9091 }}
{{- $sm := fromYaml (include "aios-apps.serviceMonitorConfig" (dict "root" $root "app" $app)) }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "aios-apps.appResourceName" $ctx }}
  labels:
    {{- include "aios-apps.appLabels" $ctx | nindent 4 }}
spec:
  replicas: {{ $app.replicas | default $root.Values.defaults.replicas | default 1 }}
  {{- with ($app.strategy | default $root.Values.defaults.strategy) }}
  strategy:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  selector:
    matchLabels:
      app.kubernetes.io/name: {{ $appName }}
      app.kubernetes.io/instance: {{ $root.Release.Name }}
  template:
    metadata:
      annotations:
        {{- if eq (include "aios-apps.catalogCreate" $root) "true" }}
        checksum/catalog: {{ include (print $root.Template.BasePath "/configmap.yaml") $root | sha256sum }}
        {{- end }}
        {{- with $app.podAnnotations }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
        {{- if $root.Values.ops.forceRestart }}
        rollme: {{ randAlphaNum 5 | quote }}
        {{- end }}
      labels:
        app.kubernetes.io/name: {{ $appName }}
        app.kubernetes.io/instance: {{ $root.Release.Name }}
    spec:
      {{- with $root.Values.global }}
      {{- with .imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- end }}
      containers:
        - name: {{ $appName }}
          image: "{{ $app.image.repository }}:{{ $app.image.tag }}"
          imagePullPolicy: {{ $app.image.pullPolicy | default "IfNotPresent" }}
          ports:
            - containerPort: {{ $app.servicePort | default 8080 }}
              name: http
            - containerPort: {{ $metricsPort }}
              name: metrics
          {{- if or $app.env $root.Values.defaults.guildHostAddr $app.envFromSecretKeys $app.extraEnv (not (hasKey ($app.env | default dict) "METRICS_PORT")) (not (hasKey ($app.env | default dict) "SERVICE_NAME")) }}
          env:
            {{- if and (not (hasKey ($app.env | default dict) "GUILD_HOST_ADDR")) (include "aios-apps.guildHostAddr" $root) }}
            - name: GUILD_HOST_ADDR
              value: {{ include "aios-apps.guildHostAddr" $root | quote }}
            {{- end }}
            {{- if not (hasKey ($app.env | default dict) "METRICS_PORT") }}
            - name: METRICS_PORT
              value: {{ $metricsPort | quote }}
            {{- end }}
            {{- if not (hasKey ($app.env | default dict) "SERVICE_NAME") }}
            - name: SERVICE_NAME
              value: {{ $appName | quote }}
            {{- end }}
            {{- range $key, $value := ($app.env | default dict) }}
            - name: {{ $key }}
              value: {{ $value | quote }}
            {{- end }}
            {{- range $app.envFromSecretKeys | default list }}
            - name: {{ .name }}
              valueFrom:
                secretKeyRef:
                  name: {{ .secretName }}
                  key: {{ .key }}
            {{- end }}
            {{- with $app.extraEnv }}
            {{- toYaml . | nindent 12 }}
            {{- end }}
          {{- end }}
          {{- if or $app.envFrom $app.envFromSecrets }}
          envFrom:
            {{- range $app.envFromSecrets | default list }}
            - secretRef:
                name: {{ . }}
            {{- end }}
            {{- with $app.envFrom }}
            {{- toYaml . | nindent 12 }}
            {{- end }}
          {{- end }}
          {{- with $app.resources }}
          resources:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- if or $app.appSecrets $app.volumeMounts }}
          volumeMounts:
            {{- if $app.appSecrets }}
            - name: app-secrets
              mountPath: {{ ($app.appSecrets.mountPath | default "/run/secrets") }}
              readOnly: true
            {{- end }}
            {{- with $app.volumeMounts }}
            {{- toYaml . | nindent 12 }}
            {{- end }}
          {{- end }}
      {{- if or $app.appSecrets $app.volumes }}
      volumes:
        {{- if $app.appSecrets }}
        - name: app-secrets
          secret:
            secretName: {{ $app.appSecrets.secretName }}
            {{- with $app.appSecrets.optional }}
            optional: {{ . }}
            {{- end }}
        {{- end }}
        {{- with $app.volumes }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
      {{- end }}
---
apiVersion: v1
kind: Service
metadata:
  name: {{ include "aios-apps.appServiceName" $ctx }}
  labels:
    {{- include "aios-apps.appLabels" $ctx | nindent 4 }}
  {{- if $sm.enabled }}
  annotations:
    prometheus.io/scrape: "true"
    prometheus.io/port: {{ $metricsPort | quote }}
    prometheus.io/path: {{ $sm.path | quote }}
  {{- end }}
spec:
  type: ClusterIP
  ports:
    - port: {{ $app.servicePort | default 8080 }}
      targetPort: http
      protocol: TCP
      name: http
    - port: {{ $metricsPort }}
      targetPort: metrics
      protocol: TCP
      name: metrics
  selector:
    app.kubernetes.io/name: {{ $appName }}
    app.kubernetes.io/instance: {{ $root.Release.Name }}
---
{{- end -}}
