{{/*
Expand the name of the chart.
*/}}
{{- define "aios-apps.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
True when this release is a single app (Helm dependency alias or one-off install).
Values live at the chart root with enabled: true; apps map is empty.
*/}}
{{- define "aios-apps.isSingleApp" -}}
{{- if not .Values.enabled -}}
{{- else if gt (len (.Values.apps | default dict)) 0 -}}
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/* App name: Helm dependency alias sets Chart.Name; else set appName in values. */}}
{{- define "aios-apps.singleAppName" -}}
{{- if .Values.appName -}}
{{- .Values.appName | trunc 63 | trimSuffix "-" -}}
{{- else if ne .Chart.Name "aios-apps" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- fail "single-app mode requires a Helm chart alias (appcd-dist) or values.appName" -}}
{{- end -}}
{{- end -}}

{{/* Deployment and Service metadata name. Dict: Release, name, singleApp, appName. */}}
{{- define "aios-apps.appResourceName" -}}
{{- if .singleApp -}}
{{- printf "%s-%s" .Release.Name .appName | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/* UI Service name (discovery endpoint host). */}}
{{- define "aios-apps.appServiceName" -}}
{{- printf "%s-ui" (include "aios-apps.appResourceName" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "aios-apps.appLabels" -}}
app.kubernetes.io/name: {{ .name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/* Default GUILD_HOST_ADDR for app → Guild HostService gRPC. */}}
{{- define "aios-apps.guildHostAddr" -}}
{{- if .Values.defaults.guildHostAddr -}}
{{- .Values.defaults.guildHostAddr -}}
{{- end -}}
{{- end -}}

{{/* Whether to render the per-release catalog ConfigMap (off when parent aggregates). */}}
{{- define "aios-apps.catalogCreate" -}}
{{- if kindIs "bool" .Values.catalog.create -}}
{{- .Values.catalog.create -}}
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/* Effective ServiceMonitor settings for one app (per-app overrides defaults). */}}
{{- define "aios-apps.serviceMonitorConfig" -}}
{{- $root := .root -}}
{{- $app := .app -}}
{{- $defaults := $root.Values.defaults.serviceMonitor | default dict -}}
{{- $override := $app.serviceMonitor | default dict -}}
enabled: {{ if kindIs "bool" $override.enabled }}{{ $override.enabled }}{{ else }}{{ $defaults.enabled | default false }}{{ end }}
interval: {{ $override.interval | default $defaults.interval | default "15s" }}
path: {{ $override.path | default $defaults.path | default "/metrics" }}
{{- end -}}

{{/* Renders ServiceMonitor for one app when enabled. Expects dict: root, name, app */}}
{{- define "aios-apps.serviceMonitorApp" -}}
{{- $root := .root }}
{{- $appName := .name }}
{{- $app := .app }}
{{- $singleApp := include "aios-apps.isSingleApp" $root | eq "true" }}
{{- $ctx := dict "name" $appName "appName" $appName "Release" $root.Release "Chart" $root.Chart "singleApp" $singleApp }}
{{- $sm := fromYaml (include "aios-apps.serviceMonitorConfig" (dict "root" $root "app" $app)) }}
{{- if $sm.enabled }}
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: {{ include "aios-apps.appResourceName" $ctx }}
  labels:
    {{- include "aios-apps.appLabels" $ctx | nindent 4 }}
spec:
  selector:
    matchLabels:
      app.kubernetes.io/name: {{ $appName }}
      app.kubernetes.io/instance: {{ $root.Release.Name }}
  endpoints:
    - port: metrics
      interval: {{ $sm.interval }}
      path: {{ $sm.path }}
---
{{- end }}
{{- end -}}
