{{/*
Expand the name of the chart.
*/}}
{{- define "context-graph-svc.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "context-graph-svc.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart name and version, used by the chart label.
*/}}
{{- define "context-graph-svc.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "context-graph-svc.labels" -}}
helm.sh/chart: {{ include "context-graph-svc.chart" . }}
{{ include "context-graph-svc.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: context-graph-svc
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "context-graph-svc.selectorLabels" -}}
app.kubernetes.io/name: {{ include "context-graph-svc.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name.
*/}}
{{- define "context-graph-svc.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "context-graph-svc.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Resolve the container image ref.
Builds: ghcr.io/appcd-dev/context-graph-svc:<tag>, defaulting tag to AppVersion.
*/}}
{{- define "context-graph-svc.image" -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag -}}
{{- printf "%s/%s:%s" .Values.image.registry .Values.image.repository $tag -}}
{{- end }}

{{/*
libpq sslmode from global.database.sslMode. Default disable for backward compatibility.
*/}}
{{- define "context-graph-svc.database.sslMode" -}}
{{- $mode := dig "database" "sslMode" "disable" (.Values.global | default dict) -}}
{{- if not (has $mode (list "disable" "allow" "prefer" "require" "verify-ca" "verify-full")) -}}
{{- fail (printf "global.database.sslMode: %q is not a libpq sslmode (disable|allow|prefer|require|verify-ca|verify-full)" $mode) -}}
{{- end -}}
{{- $mode -}}
{{- end -}}
