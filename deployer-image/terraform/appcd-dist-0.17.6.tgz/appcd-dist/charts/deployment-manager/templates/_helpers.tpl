{{/*
libpq sslmode from global.database.sslMode. Default disable for backward compatibility.
*/}}
{{- define "deployment-manager.database.sslMode" -}}
{{- $mode := dig "database" "sslMode" "disable" (.Values.global | default dict) -}}
{{- if not (has $mode (list "disable" "allow" "prefer" "require" "verify-ca" "verify-full")) -}}
{{- fail (printf "global.database.sslMode: %q is not a libpq sslmode (disable|allow|prefer|require|verify-ca|verify-full)" $mode) -}}
{{- end -}}
{{- $mode -}}
{{- end -}}
