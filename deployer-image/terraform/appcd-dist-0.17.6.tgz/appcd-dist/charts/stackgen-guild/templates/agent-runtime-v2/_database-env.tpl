{{/*
Database connection for the runtime and its migration Job.
Host, port, user and password come from an existing Secret, with the same keys
context-graph-svc reads. Nothing here creates a Secret.
*/}}
{{- define "stackgen-guild.runtimeDatabaseEnv" -}}
{{- $credentials := .Values.agentRuntimeV2.databaseCredentials -}}
{{- $secretName := required "agentRuntimeV2.databaseCredentials.existingSecret is required when agentRuntimeV2.persistence.enabled" $credentials.existingSecret -}}
- name: AGENT_RUNTIME_V2_PERSISTENCE__HOST
  valueFrom:
    secretKeyRef:
      name: {{ $secretName | quote }}
      key: {{ $credentials.keys.host | quote }}
      optional: false
- name: AGENT_RUNTIME_V2_PERSISTENCE__PORT
  valueFrom:
    secretKeyRef:
      name: {{ $secretName | quote }}
      key: {{ $credentials.keys.port | quote }}
      optional: false
- name: AGENT_RUNTIME_V2_PERSISTENCE__USER
  valueFrom:
    secretKeyRef:
      name: {{ $secretName | quote }}
      key: {{ $credentials.keys.username | quote }}
      optional: false
- name: AGENT_RUNTIME_V2_PERSISTENCE__PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ $secretName | quote }}
      key: {{ $credentials.keys.password | quote }}
      optional: false
- name: AGENT_RUNTIME_V2_PERSISTENCE__DATABASE
  value: {{ default .Values.config.database.name $credentials.database | quote }}
- name: AGENT_RUNTIME_V2_PERSISTENCE__SSL_MODE
  value: {{ include "stackgen-guild.database.sslMode" . | quote }}
{{- end -}}
