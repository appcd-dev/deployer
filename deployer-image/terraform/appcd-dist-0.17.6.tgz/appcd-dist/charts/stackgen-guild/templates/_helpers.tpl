{{/*
Expand the name of the chart.
*/}}
{{- define "stackgen-guild.name" -}}
{{- default .Chart.Name .Values.global.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "stackgen-guild.fullname" -}}
{{- if .Values.global.fullnameOverride }}
{{- .Values.global.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.global.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "stackgen-guild.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "stackgen-guild.labels" -}}
helm.sh/chart: {{ include "stackgen-guild.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: stackgen-guild
{{- end }}

{{/*
Selector labels for a given component.
Usage: {{ include "stackgen-guild.selectorLabels" (dict "root" . "component" "guild") }}
*/}}
{{- define "stackgen-guild.selectorLabels" -}}
app.kubernetes.io/name: {{ include "stackgen-guild.name" .root }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Service account name.
*/}}
{{- define "stackgen-guild.serviceAccountName" -}}
{{- if .Values.global.serviceAccount.create }}
{{- default (include "stackgen-guild.fullname" .) .Values.global.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.global.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
mcp-gateway ServiceAccount. Bound on integration-sidecar RBAC when
mcpGateway.enabled is true. When false, the Guild SA is the subject instead
(older tagged images). Current Guild binaries do not LaunchAndConnect.
create=false without a name would bind RBAC and the Deployment to an account
this chart never creates.
*/}}
{{- define "stackgen-guild.mcpGatewayServiceAccountName" -}}
{{- if and (not .Values.mcpGateway.serviceAccount.create) (not .Values.mcpGateway.serviceAccount.name) -}}
{{- fail "mcpGateway.serviceAccount.name is required when mcpGateway.serviceAccount.create is false" -}}
{{- end -}}
{{- if .Values.mcpGateway.serviceAccount.name }}
{{- .Values.mcpGateway.serviceAccount.name }}
{{- else }}
{{- printf "%s-mcp-gateway" (include "stackgen-guild.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Resolve image for a component.
Usage: {{ include "stackgen-guild.image" (dict "root" . "svc" .Values.guild "component" "guild") }}
Builds: ghcr.io/appcd-dev/stackgen-guild-guild:1.0.0 (matches Makefile container/ targets).
When svc.image.repository is set, it overrides the auto-suffixed name.
*/}}
{{- define "stackgen-guild.image" -}}
{{- $registry := default .root.Values.global.image.registry .svc.image.registry -}}
{{- $baseRepo := default .root.Values.global.image.repository .svc.image.repository -}}
{{- $tag := default (default .root.Chart.AppVersion .root.Values.global.image.tag) .svc.image.tag -}}
{{- if .svc.image.repository -}}
{{- printf "%s/%s:%s" $registry $baseRepo $tag -}}
{{- else -}}
{{- printf "%s/%s-%s:%s" $registry $baseRepo .component $tag -}}
{{- end -}}
{{- end }}

{{/*
Agents v2 runtime image: registry/repository:tag.
An empty agentRuntimeV2.image.tag takes Guild's effective tag, so the two images
always come from one build. CI tags both images the same way.
*/}}
{{- define "stackgen-guild.agentRuntimeV2.image" -}}
{{- $image := .Values.agentRuntimeV2.image -}}
{{- $guildTag := default (default .Chart.AppVersion .Values.global.image.tag) .Values.guild.image.tag -}}
{{- printf "%s/%s:%s" $image.registry $image.repository (default $guildTag $image.tag) -}}
{{- end }}

{{/*
libpq sslmode from global.database.sslMode, copied from context-graph-svc.
Default disable. Anything that is not a libpq mode fails the render.
*/}}
{{- define "stackgen-guild.database.sslMode" -}}
{{- $mode := dig "database" "sslMode" "disable" (.Values.global | default dict) -}}
{{- if not (has $mode (list "disable" "allow" "prefer" "require" "verify-ca" "verify-full")) -}}
{{- fail (printf "global.database.sslMode: %q is not a libpq sslmode (disable|allow|prefer|require|verify-ca|verify-full)" $mode) -}}
{{- end -}}
{{- $mode -}}
{{- end -}}

{{/*
Resolve image pull policy for a component.
Usage: {{ include "stackgen-guild.imagePullPolicy" (dict "root" . "svc" .Values.guild) }}
*/}}
{{- define "stackgen-guild.imagePullPolicy" -}}
{{- default .root.Values.global.image.pullPolicy .svc.image.pullPolicy -}}
{{- end }}

{{/*
PostgreSQL host.
  - If the Bitnami postgresql sub-chart is enabled → use sub-chart service name.
  - Otherwise → use config.database.host (e.g. "rdsproxy" for RDS via socat).
*/}}
{{- define "stackgen-guild.pgHost" -}}
{{- if .Values.postgresql.enabled -}}
{{- printf "%s-postgresql" .Release.Name -}}
{{- else -}}
{{- required "config.database.host is required when postgresql.enabled=false" .Values.config.database.host -}}
{{- end -}}
{{- end }}

{{/*
  - Must be provided via config.database.url, typically sourced from a Kubernetes Secret.
  - For production, prefer using a Secret-backed value or config.database.existingSecret.
*/}}
{{- define "stackgen-guild.databaseUrl" -}}
{{- if .Values.config.database.url -}}
{{- .Values.config.database.url -}}
{{- else -}}
{{- required "config.database.url is required when using stackgen-guild.databaseUrl. Provide this URL via a Kubernetes Secret-backed value (config.database.url) or use config.database.existingSecret." .Values.config.database.url -}}
{{- end -}}
{{- end }}

{{/*
NATS URL.
  - If the nats sub-chart is enabled and no explicit URL → use sub-chart service.
  - If config.nats.url is set → use that (external NATS).
  - Otherwise → fail.
*/}}
{{- define "stackgen-guild.natsUrl" -}}
{{- if .Values.config.nats.url -}}
{{- .Values.config.nats.url -}}
{{- else if .Values.nats.enabled -}}
{{- printf "nats://%s-nats:4222" .Release.Name -}}
{{- else -}}
{{- required "config.nats.url is required when nats.enabled=false" .Values.config.nats.url -}}
{{- end -}}
{{- end }}

{{/*
Temporal host URL.
  - If config.temporal.hostUrl is set → use that (e.g. cross-namespace).
  - If the temporal sub-chart is enabled → use sub-chart frontend service.
  - Otherwise → fail.
*/}}
{{- define "stackgen-guild.temporalHostUrl" -}}
{{- if .Values.config.temporal.hostUrl -}}
{{- .Values.config.temporal.hostUrl -}}
{{- else if .Values.temporal.enabled -}}
{{- printf "%s-temporal-frontend:7233" .Release.Name -}}
{{- else -}}
{{- required "config.temporal.hostUrl is required when temporal.enabled=false" .Values.config.temporal.hostUrl -}}
{{- end -}}
{{- end }}

{{/*
Vault service gRPC host (external — already deployed in cloud).
*/}}
{{- define "stackgen-guild.vaultGrpcHost" -}}
{{- .Values.config.vault.host -}}
{{- end }}

{{/*
Vault gRPC port (external — already deployed in cloud).
*/}}
{{- define "stackgen-guild.vaultGrpcPort" -}}
{{- .Values.config.vault.grpcPort -}}
{{- end }}

{{/*
Langfuse secret name.
Uses existingSecret when provided, otherwise the chart-managed secret.
*/}}
{{- define "stackgen-guild.langfuseSecretName" -}}
{{- if .Values.config.langfuse.existingSecret -}}
{{- .Values.config.langfuse.existingSecret -}}
{{- else -}}
{{- printf "%s-langfuse" (include "stackgen-guild.fullname" .) -}}
{{- end -}}
{{- end }}

{{/*
Guild service internal URL for the gateway to call.
*/}}
{{- define "stackgen-guild.guildServiceUrl" -}}
{{- printf "http://%s-guild:%s" (include "stackgen-guild.fullname" .) (.Values.guild.service.port | toString) -}}
{{- end }}

{{/*
Guild service internal gRPC host:port for gateway tenant/credential resolution.
*/}}
{{- define "stackgen-guild.guildServiceGrpcUrl" -}}
{{- printf "%s-guild:9090" (include "stackgen-guild.fullname" .) -}}
{{- end }}

{{/*
Qdrant Vector Database Host.
  - If config.vectorStore.qdrant.host is set → use that (e.g. cross-namespace or external).
  - If the qdrant sub-chart is enabled → use sub-chart service.
  - Otherwise → fail (if vector store is qdrant).
*/}}
{{- define "stackgen-guild.qdrantHost" -}}
{{- if .Values.config.vectorStore.qdrant.host -}}
{{- .Values.config.vectorStore.qdrant.host -}}
{{- else if .Values.qdrant.enabled -}}
{{- printf "%s-qdrant:6333" .Release.Name -}}
{{- else -}}
{{- required "config.vectorStore.qdrant.host is required when vectorStore.provider=qdrant and qdrant.enabled=false" .Values.config.vectorStore.qdrant.host -}}
{{- end -}}
{{- end }}

{{/*
Docling in-cluster service host (mirrors docling.fullname from the sub-chart).
*/}}
{{- define "stackgen-guild.doclingServiceHost" -}}
{{- if .Values.docling.fullnameOverride -}}
{{- .Values.docling.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default "docling" .Values.docling.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Docling base URL.
  - If config.docling.baseURL is set → use that (external Docling instance).
  - If the docling sub-chart is enabled → use in-cluster service.
  - Otherwise → empty (document parsing disabled).
*/}}
{{- define "stackgen-guild.doclingBaseURL" -}}
{{- if .Values.config.docling.baseURL -}}
{{- .Values.config.docling.baseURL -}}
{{- else if .Values.docling.enabled -}}
{{- printf "http://%s:5001" (include "stackgen-guild.doclingServiceHost" .) -}}
{{- end -}}
{{- end }}

{{/*
Agent Sandbox Namespace.
*/}}
{{- define "stackgen-guild.sandboxNamespace" -}}
{{- if .Values.config.agentRuntime.kubernetes.namespace -}}
{{- .Values.config.agentRuntime.kubernetes.namespace -}}
{{- else -}}
{{- printf "guild-sandbox-%s" .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
PVC name for shared blob / S3 CSI storage (guild and agentworker only).
Override with config.blobStorage.claimName when the platform uses a non-standard name.
*/}}
{{- define "stackgen-guild.blobStorageClaimName" -}}
{{- if .Values.config.blobStorage.claimName -}}
{{- .Values.config.blobStorage.claimName -}}
{{- else -}}
{{- printf "storage-%s" .Release.Namespace -}}
{{- end -}}
{{- end }}

{{/*
Blob storage mount path — single source of truth for:
  - the K8s volumeMount path on guild & agentworker pods
  - the storage_path in the Guild config.yaml (read by pkg/storage.Store)
  - the ARTIFACTS_DIR env var

Using one helper guarantees the K8s mount and the application's view of the
filesystem agree. Without this, the configmap, deployment and env var each had
their own default, and a stray GUILD_STORAGE_PATH env override silently sent
all reads/writes to an ephemeral emptyDir at /tmp instead of the S3-CSI PVC.
*/}}
{{- define "stackgen-guild.blobStorageMountPath" -}}
{{- .Values.config.blobStorage.mountPath | default "/data/artifacts" -}}
{{- end }}

{{/* The agents v2 runtime shares Guild's volume, in its own subdirectory. */}}
{{- define "stackgen-guild.agentRuntimeSharedRoot" -}}
{{- printf "%s/%s" (include "stackgen-guild.blobStorageMountPath" . | trimSuffix "/") .Values.agentRuntimeV2.sharedRootSubdir -}}
{{- end }}

{{/*
Integration / MCP sidecar namespace (defaults to agent sandbox namespace).
*/}}
{{- define "stackgen-guild.integrationNamespace" -}}
{{- if .Values.config.agentRuntime.kubernetes.integrations.namespace -}}
{{- .Values.config.agentRuntime.kubernetes.integrations.namespace -}}
{{- else -}}
{{- include "stackgen-guild.sandboxNamespace" . -}}
{{- end -}}
{{- end }}

{{/*
Validate extraMounts: unique name, mountPath required, exactly one source,
declared key present for inline data, and no collision with built-in volume names.
Call once from extra-mounts.yaml (side effect: fail on bad values).
*/}}
{{- define "stackgen-guild.validateExtraMounts" -}}
{{- $reserved := dict "secrets" true "tmp" true "home" true "config-volume" true "guild-storage" true "aios-apps-catalog" true -}}
{{- $names := dict -}}
{{- range $i, $m := (.Values.extraMounts | default list) -}}
{{- if not $m.name -}}
{{- fail (printf "extraMounts[%d]: name is required" $i) -}}
{{- end -}}
{{- if hasKey $reserved $m.name -}}
{{- fail (printf "extraMounts[%q]: name collides with a built-in volume (secrets, tmp, home, config-volume, guild-storage, aios-apps-catalog)" $m.name) -}}
{{- end -}}
{{- if hasKey $names $m.name -}}
{{- fail (printf "extraMounts: duplicate name %q" $m.name) -}}
{{- end -}}
{{- $_ := set $names $m.name true -}}
{{- if not $m.mountPath -}}
{{- fail (printf "extraMounts[%q]: mountPath is required" $m.name) -}}
{{- end -}}
{{- $key := $m.key | default "ca-bundle.crt" -}}
{{- $sources := 0 -}}
{{- if $m.existingConfigMap -}}{{- $sources = add $sources 1 -}}{{- end -}}
{{- if $m.existingSecret -}}{{- $sources = add $sources 1 -}}{{- end -}}
{{- if and $m.configMap (or $m.configMap.data $m.configMap.binaryData) -}}
{{- $sources = add $sources 1 -}}
{{- $inData := and $m.configMap.data (hasKey $m.configMap.data $key) -}}
{{- $inBinary := and $m.configMap.binaryData (hasKey $m.configMap.binaryData $key) -}}
{{- if and (not $inData) (not $inBinary) -}}
{{- fail (printf "extraMounts[%q]: key %q not found in configMap.data/binaryData" $m.name $key) -}}
{{- end -}}
{{- end -}}
{{- if and $m.secret (or $m.secret.stringData $m.secret.data) -}}
{{- $sources = add $sources 1 -}}
{{- $inString := and $m.secret.stringData (hasKey $m.secret.stringData $key) -}}
{{- $inData := and $m.secret.data (hasKey $m.secret.data $key) -}}
{{- if and (not $inString) (not $inData) -}}
{{- fail (printf "extraMounts[%q]: key %q not found in secret.stringData/data" $m.name $key) -}}
{{- end -}}
{{- end -}}
{{- if ne $sources 1 -}}
{{- fail (printf "extraMounts[%q]: set exactly one of existingConfigMap, existingSecret, configMap.data, or secret.stringData/data" $m.name) -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Kubernetes object name for an extraMount entry (ConfigMap or Secret name).
*/}}
{{- define "stackgen-guild.extraMountObjectName" -}}
{{- if .existingConfigMap -}}
{{- .existingConfigMap -}}
{{- else if .existingSecret -}}
{{- .existingSecret -}}
{{- else if and .configMap .configMap.name -}}
{{- .configMap.name -}}
{{- else if and .secret .secret.name -}}
{{- .secret.name -}}
{{- else -}}
{{- .name -}}
{{- end -}}
{{- end }}

{{/*
Data key for an extraMount (default ca-bundle.crt).
*/}}
{{- define "stackgen-guild.extraMountKey" -}}
{{- .key | default "ca-bundle.crt" -}}
{{- end }}

{{/*
SubPath for the volume mount (default = key).
*/}}
{{- define "stackgen-guild.extraMountSubPath" -}}
{{- .subPath | default (include "stackgen-guild.extraMountKey" .) -}}
{{- end }}

{{/*
True when the mount sources a Secret rather than a ConfigMap.
*/}}
{{- define "stackgen-guild.extraMountIsSecret" -}}
{{- if or .existingSecret (and .secret (or .secret.stringData .secret.data)) -}}
true
{{- end -}}
{{- end }}

{{/*
PodSpec volumes expanded from extraMounts.

Do not left-chomp (`{{-`) before emitted YAML keys: chomping the newline after
`- name:` glues the next key onto the same line and yields invalid PodSpec YAML.
*/}}
{{- define "stackgen-guild.extraMountVolumes" -}}
{{- range .Values.extraMounts | default list }}
- name: {{ .name }}
{{ if eq (include "stackgen-guild.extraMountIsSecret" .) "true" }}
  secret:
    secretName: {{ include "stackgen-guild.extraMountObjectName" . }}
    items:
      - key: {{ include "stackgen-guild.extraMountKey" . }}
        path: {{ include "stackgen-guild.extraMountSubPath" . }}
{{ else }}
  configMap:
    name: {{ include "stackgen-guild.extraMountObjectName" . }}
    items:
      - key: {{ include "stackgen-guild.extraMountKey" . }}
        path: {{ include "stackgen-guild.extraMountSubPath" . }}
{{ end }}
{{- end }}
{{- end }}

{{/*
PodSpec volumeMounts expanded from extraMounts.

Preserve the newline after readOnly so a following list item stays on its own line.
*/}}
{{- define "stackgen-guild.extraMountVolumeMounts" -}}
{{- range .Values.extraMounts | default list }}
- name: {{ .name }}
  mountPath: {{ .mountPath }}
  subPath: {{ include "stackgen-guild.extraMountSubPath" . }}
  readOnly: {{ .readOnly | default true }}
{{ end }}
{{- end }}

{{/*
Env vars expanded from extraMounts[].env (each value = mountPath).

Preserve newlines between env entries and between mounts that declare env.
*/}}
{{- define "stackgen-guild.extraMountEnv" -}}
{{- range .Values.extraMounts | default list }}
{{- $path := .mountPath }}
{{- range .env | default list }}
- name: {{ . }}
  value: {{ $path | quote }}
{{ end }}
{{- end }}
{{- end }}

{{/*
Render envFrom secretRef entries from guild.envFromSecrets / gateway.envFromSecrets.
Each entry: { name: "openai-secret", optional: true }. optional defaults to true.
*/}}
{{- define "stackgen-guild.envFromSecretRefs" -}}
{{- range .secrets }}
- secretRef:
    name: {{ .name }}
    optional: {{ .optional | default true }}
{{- end }}
{{- end }}
