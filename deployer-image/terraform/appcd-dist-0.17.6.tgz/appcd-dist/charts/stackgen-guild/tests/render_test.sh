#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../../../.."
# Fresh CI runners and local shells use the same repositories without changing
# the operator's global Helm configuration. URLs match Chart.yaml.
helm_tmp=$(mktemp -d)
trap 'rm -rf -- "$helm_tmp"' EXIT
export HELM_CONFIG_HOME="$helm_tmp/config"
export HELM_CACHE_HOME="$helm_tmp/cache"
export HELM_DATA_HOME="$helm_tmp/data"
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo add nats https://nats-io.github.io/k8s/helm/charts/
helm repo add qdrant https://qdrant.to/helm
helm dependency build --skip-refresh iac/helm/stackgen-guild
# Defaults must install with no overrides: the agents v2 runtime is off.
helm lint iac/helm/stackgen-guild
# The settings an environment uses to turn the runtime on.
helm lint iac/helm/stackgen-guild \
  --set agentRuntimeV2.enabled=true \
  --set agentRuntimeV2.databaseCredentials.existingSecret=appcd-secrets \
  --set agentRuntimeV2.serviceMonitor.enabled=true
uv run --locked --project python --package agent-runtime-v2 \
  pytest iac/helm/stackgen-guild/tests/test_render.py -q
