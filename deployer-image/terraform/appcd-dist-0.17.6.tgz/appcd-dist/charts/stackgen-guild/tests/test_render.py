"""Render the real chart and verify the runtime's deployment contract."""

import subprocess
from pathlib import Path

import pytest
import yaml

CHART = Path(__file__).resolve().parents[1]
COMPONENT = "agent-runtime-v2"
MIGRATION = "agent-runtime-v2-migration"
# What an environment sets to turn the runtime on.
ENABLED = (
    "agentRuntimeV2.enabled=true",
    "agentRuntimeV2.databaseCredentials.existingSecret=appcd-secrets",
)
RDS_KEYS = {
    "AGENT_RUNTIME_V2_PERSISTENCE__HOST": "rds_endpoint",
    "AGENT_RUNTIME_V2_PERSISTENCE__PORT": "rds_port",
    "AGENT_RUNTIME_V2_PERSISTENCE__USER": "rds_username",
    "AGENT_RUNTIME_V2_PERSISTENCE__PASSWORD": "rds_password",
}


def helm_template(*settings: str, operator: bool = False) -> list[dict]:
    command = ["helm", "template", "test", str(CHART), "--namespace", "appcd-ai"]
    if operator:
        command.extend(["--api-versions", "monitoring.coreos.com/v1/ServiceMonitor"])
    for setting in settings:
        command.extend(["--set", setting])
    output = subprocess.check_output(command, text=True)
    return [item for item in yaml.safe_load_all(output) if item]


def render_error(*settings: str) -> str:
    """The message a render fails with."""
    command = ["helm", "template", "test", str(CHART)]
    for setting in settings:
        command.extend(["--set", setting])
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode != 0
    return result.stderr


def render_component(component: str, *settings: str, operator: bool = False) -> dict[str, dict]:
    return {
        item["kind"]: item
        for item in helm_template(*settings, operator=operator)
        if item["metadata"].get("labels", {}).get("app.kubernetes.io/component") == component
    }


def render(*settings: str, operator: bool = False) -> dict[str, dict]:
    """The runtime's objects with the runtime turned on, plus any extra settings."""
    return render_component(COMPONENT, *ENABLED, *settings, operator=operator)


def container_env(workload: dict) -> dict[str, dict]:
    container = workload["spec"]["template"]["spec"]["containers"][0]
    return {item["name"]: item for item in container["env"]}


def secret_refs(env: dict[str, dict]) -> dict[str, str]:
    return {
        name: item["valueFrom"]["secretKeyRef"]["key"]
        for name, item in env.items()
        if item.get("valueFrom", {}).get("secretKeyRef", {}).get("name") == "appcd-secrets"
    }


def guild_env(*settings: str) -> dict[str, dict]:
    return container_env(render_component("guild", *settings)["Deployment"])


def test_default_install_has_no_runtime_and_tells_guild_so() -> None:
    """The runtime is off until an environment turns it on.

    Guild hears an explicit "false", so it never sends a turn to a runtime that
    is not deployed. The other runtime settings stay out of Guild's env.
    """
    documents = helm_template()
    runtime = [
        item["metadata"]["name"]
        for item in documents
        if "agent-runtime-v2" in item["metadata"]["name"]
    ]
    assert runtime == []
    env = guild_env()
    assert env["GUILD_AGENT_RUNTIME_V2_ENABLED"]["value"] == "false"
    assert [name for name in env if name.startswith("GUILD_AGENT_RUNTIME_V2_")] == [
        "GUILD_AGENT_RUNTIME_V2_ENABLED"
    ]


def test_enabled_runtime_tells_guild_it_is_deployed() -> None:
    assert guild_env(*ENABLED)["GUILD_AGENT_RUNTIME_V2_ENABLED"]["value"] == "true"


def test_enabled_runtime_needs_the_database_secret() -> None:
    assert (
        "agentRuntimeV2.databaseCredentials.existingSecret is required when "
        "agentRuntimeV2.persistence.enabled" in render_error("agentRuntimeV2.enabled=true")
    )


def test_one_hook_job_migrates_before_the_workers_start() -> None:
    objects = render_component(MIGRATION, *ENABLED)
    assert set(objects) == {"Job"}
    job = objects["Job"]
    annotations = job["metadata"]["annotations"]
    assert annotations["helm.sh/hook"] == "pre-install,pre-upgrade"
    assert annotations["helm.sh/hook-delete-policy"] == "before-hook-creation"
    assert job["spec"]["backoffLimit"] == 0
    pod = job["spec"]["template"]
    # Without the name label, the runtime Service and PDB never select this pod.
    assert "app.kubernetes.io/name" not in pod["metadata"]["labels"]
    assert pod["spec"]["restartPolicy"] == "Never"
    assert pod["spec"]["containers"][0]["command"] == ["agent-runtime-v2-migrate"]
    env = container_env(job)
    assert secret_refs(env) == RDS_KEYS
    assert env["AGENT_RUNTIME_V2_PERSISTENCE__ENABLED"]["value"] == "true"
    assert env["AGENT_RUNTIME_V2_PERSISTENCE__DATABASE"]["value"] == "guild_db"


def test_migration_job_follows_its_switches() -> None:
    assert render_component(MIGRATION, *ENABLED, "agentRuntimeV2.migrations.enabled=false") == {}
    no_persistence = (
        "agentRuntimeV2.persistence.enabled=false",
        "agentRuntimeV2.analysis.enabled=false",
    )
    assert render_component(MIGRATION, *ENABLED, *no_persistence) == {}


def test_enabled_runtime_reads_the_database_from_the_shared_secret() -> None:
    objects = render()
    assert set(objects) == {"Deployment", "Service", "PodDisruptionBudget"}
    pod = objects["Deployment"]["spec"]["template"]["spec"]
    assert "initContainers" not in pod
    assert pod["enableServiceLinks"] is False
    assert pod["securityContext"]["runAsUser"] == 1001
    env = container_env(objects["Deployment"])
    assert secret_refs(env) == RDS_KEYS
    assert all(env[name]["valueFrom"]["secretKeyRef"]["optional"] is False for name in RDS_KEYS)
    assert env["AGENT_RUNTIME_V2_PERSISTENCE__ENABLED"]["value"] == "true"
    assert env["AGENT_RUNTIME_V2_PERSISTENCE__SSL_MODE"]["value"] == "disable"
    container = pod["containers"][0]
    assert container["resources"] == {
        "requests": {"cpu": "2", "memory": "2Gi"},
        "limits": {"memory": "4Gi"},
    }
    assert container["startupProbe"]["httpGet"]["path"] == "/healthz"
    assert container["readinessProbe"]["httpGet"]["path"] == "/healthz"
    # /healthz checks the database, and a database blip must not restart pods.
    assert container["livenessProbe"] == {"tcpSocket": {"port": "http"}}


def test_database_name_and_ssl_mode_can_be_set() -> None:
    env = container_env(
        render(
            "agentRuntimeV2.databaseCredentials.database=runtime_db",
            "global.database.sslMode=require",
        )["Deployment"]
    )
    assert env["AGENT_RUNTIME_V2_PERSISTENCE__DATABASE"]["value"] == "runtime_db"
    assert env["AGENT_RUNTIME_V2_PERSISTENCE__SSL_MODE"]["value"] == "require"


def test_an_unknown_ssl_mode_fails_the_render() -> None:
    error = render_error(*ENABLED, "global.database.sslMode=sometimes")
    assert "is not a libpq sslmode" in error


def test_service_names_each_port_once() -> None:
    """Kubernetes rejects a Service that lists one port twice."""
    objects = render()
    ports = {
        port["name"]: (port["port"], port["targetPort"])
        for port in objects["Service"]["spec"]["ports"]
    }
    assert ports == {"http": (8083, "http"), "metrics": (9091, "metrics")}
    container = objects["Deployment"]["spec"]["template"]["spec"]["containers"][0]
    assert {port["name"]: port["containerPort"] for port in container["ports"]} == {
        "http": 8083,
        "metrics": 9091,
    }
    env = container_env(objects["Deployment"])
    assert env["AGENT_RUNTIME_V2_METRICS__PORT"]["value"] == "9091"
    assert env["AGENT_RUNTIME_V2_METRICS__DISABLED"]["value"] == "false"


def test_disabled_metrics_leave_only_the_app_port() -> None:
    objects = render("agentRuntimeV2.metrics.disabled=true")
    assert [port["name"] for port in objects["Service"]["spec"]["ports"]] == ["http"]


@pytest.mark.parametrize(
    ("setting", "message"),
    [
        ("agentRuntimeV2.metrics.disabled=true", "requires agentRuntimeV2.metrics.disabled=false"),
        ("agentRuntimeV2.metrics.port=8083", "must differ from agentRuntimeV2.service.port"),
    ],
)
def test_metrics_that_cannot_be_scraped_fail_the_render(setting: str, message: str) -> None:
    error = render_error(*ENABLED, "agentRuntimeV2.serviceMonitor.enabled=true", setting)
    assert message in error


def test_scraping_follows_only_the_runtime_flag() -> None:
    """Guild's own ServiceMonitor flag no longer turns on the runtime's scrape."""
    quiet = render("guild.serviceMonitor.enabled=true", operator=True)
    assert "ServiceMonitor" not in quiet
    assert "annotations" not in quiet["Service"]["metadata"]

    scraped = render("agentRuntimeV2.serviceMonitor.enabled=true", operator=True)
    annotations = scraped["Service"]["metadata"]["annotations"]
    assert annotations["prometheus.io/port"] == "9091"
    assert annotations["prometheus.io/path"] == "/metrics"
    assert scraped["ServiceMonitor"]["spec"]["endpoints"][0]["port"] == "metrics"


def test_runtime_image_follows_guild_unless_pinned() -> None:
    def image(*settings: str) -> str:
        pods = [
            render(*settings)["Deployment"],
            render_component(MIGRATION, *ENABLED, *settings)["Job"],
        ]
        images = {pod["spec"]["template"]["spec"]["containers"][0]["image"] for pod in pods}
        assert len(images) == 1
        return images.pop()

    repository = "ghcr.io/appcd-dev/stackgen-guild-agent-runtime-v2"
    guild_tag = yaml.safe_load((CHART / "values.yaml").read_text())["guild"]["image"]["tag"]
    assert image() == f"{repository}:{guild_tag}"
    assert image("guild.image.tag=vX") == f"{repository}:vX"
    assert image("guild.image.tag=vX", "agentRuntimeV2.image.tag=vY") == f"{repository}:vY"


def test_runtime_features_can_be_disabled_explicitly() -> None:
    objects = render(
        "agentRuntimeV2.analysis.enabled=false",
        "agentRuntimeV2.persistence.enabled=false",
        "agentRuntimeV2.databaseCredentials.existingSecret=",
        "agentRuntimeV2.observability.traces.enabled=false",
    )
    env = container_env(objects["Deployment"])
    assert "AGENT_RUNTIME_V2_PERSISTENCE__ENABLED" not in env
    assert "AGENT_RUNTIME_V2_PERSISTENCE__PASSWORD" not in env
    assert env["AGENT_RUNTIME_V2_OBSERVABILITY__TRACES__ENABLED"]["value"] == "false"


def test_runtime_passes_storage_and_signal_settings() -> None:
    env = {name: item.get("value") for name, item in container_env(render()["Deployment"]).items()}
    assert env["AGENT_RUNTIME_V2_SHARED_ROOT"] == "/data/artifacts/agent-runtime-v2"
    assert env["AGENT_RUNTIME_V2_PERSISTENCE__HISTORY_TURN_LIMIT"] == "10"
    assert env["AGENT_RUNTIME_V2_TURN_TIMEOUT_SECONDS"] == "3600"
    assert env["AGENT_RUNTIME_V2_MAX_CONCURRENT_TURNS"] == "50"
    assert env["AGENT_RUNTIME_V2_ANALYSIS__SESSION_BYTES"] == "134217728"
    assert env["AGENT_RUNTIME_V2_ANALYSIS__SESSION_REUSE_ENABLED"] == "false"
    assert env["AGENT_RUNTIME_V2_OBSERVABILITY__TRACES__ENABLED"] == "true"
    assert env["AGENT_RUNTIME_V2_OBSERVABILITY__LOGS__ENABLED"] == "false"
    assert env["AGENT_RUNTIME_V2_OBSERVABILITY__LANGFUSE__ENABLED"] == "false"
    assert env["AGENT_RUNTIME_V2_OBSERVABILITY__LANGFUSE__BODY_MODE"] == "full"
    assert env["AGENT_RUNTIME_V2_OBSERVABILITY__DEPLOYMENT_ENVIRONMENT"] == "appcd-ai"
    assert "AGENT_RUNTIME_V2_DIRECT_API_TOKEN" not in env
    assert (
        env["AGENT_RUNTIME_V2_OBSERVABILITY__OTLP__ENDPOINT"]
        == "otel-collector.devopsnow.svc.cluster.local:4317"
    )


def test_langfuse_secret_is_scoped_to_runtime_only_when_enabled() -> None:
    normal = container_env(render()["Deployment"])
    assert normal["AGENT_RUNTIME_V2_OBSERVABILITY__LANGFUSE__ENABLED"]["value"] == "false"
    assert "AGENT_RUNTIME_V2_OBSERVABILITY__LANGFUSE__HOST" not in normal
    configured = container_env(
        render(
            "agentRuntimeV2.observability.langfuse.enabled=true",
            "agentRuntimeV2.observability.langfuse.secretName=shared-langfuse",
        )["Deployment"]
    )
    assert configured["AGENT_RUNTIME_V2_OBSERVABILITY__LANGFUSE__ENABLED"]["value"] == "true"
    for suffix, key in (("HOST", "LANGFUSE_HOST"), ("PUBLIC_KEY", "LANGFUSE_PUBLIC_KEY"), ("SECRET_KEY", "LANGFUSE_SECRET_KEY")):
        reference = configured[f"AGENT_RUNTIME_V2_OBSERVABILITY__LANGFUSE__{suffix}"]["valueFrom"]["secretKeyRef"]
        assert reference["name"] == "shared-langfuse"
        assert reference["key"] == key


def test_provider_secret_and_custom_storage_are_passed_without_plaintext() -> None:
    objects = render(
        "agentRuntimeV2.analysis.enabled=false",
        "config.blobStorage.mountPath=/shared/",
        "config.blobStorage.enabled=false",
        "agentRuntimeV2.sharedRootSubdir=runtime",
        "agentRuntimeV2.providerSecrets[0].secret=provider-key",
        "agentRuntimeV2.providerSecrets[0].key=OPENAI_API_KEY",
        "agentRuntimeV2.providerSecrets[0].env=AGENT_RUNTIME_V2_OPENAI_API_KEY",
        "agentRuntimeV2.providerSecrets[0].optional=false",
        "agentRuntimeV2.observability.otlpEndpoint=collector:4317",
    )
    pod = objects["Deployment"]["spec"]["template"]["spec"]
    env = container_env(objects["Deployment"])
    assert env["AGENT_RUNTIME_V2_SHARED_ROOT"]["value"] == "/shared/runtime"
    assert env["AGENT_RUNTIME_V2_OBSERVABILITY__OTLP__ENDPOINT"]["value"] == "collector:4317"
    assert env["AGENT_RUNTIME_V2_OPENAI_API_KEY"]["valueFrom"]["secretKeyRef"] == {
        "name": "provider-key",
        "key": "OPENAI_API_KEY",
        "optional": False,
    }
    assert {volume["name"]: volume for volume in pod["volumes"]}["blob-storage"]["emptyDir"] == {}


def test_direct_model_api_needs_only_the_runtime_url() -> None:
    settings = ("agentRuntimeV2.directAPI.enabled=true",)
    runtime_env = container_env(render(*settings)["Deployment"])
    enabled_guild = guild_env(*ENABLED, *settings)
    assert "AGENT_RUNTIME_V2_DIRECT_API_TOKEN" not in runtime_env
    assert "GUILD_AGENT_RUNTIME_V2_DIRECT_API_TOKEN" not in enabled_guild
    assert enabled_guild["GUILD_AGENT_RUNTIME_V2_HTTP_URL"]["value"].endswith(
        "-agent-runtime-v2:8083"
    )
    assert "GUILD_AGENT_RUNTIME_V2_HTTP_URL" not in guild_env(*settings)
    assert "GUILD_AGENT_RUNTIME_V2_HTTP_URL" not in guild_env(*ENABLED)


def test_analysis_uses_private_disk_volume_only_when_enabled() -> None:
    disabled_pod = render("agentRuntimeV2.analysis.enabled=false")["Deployment"]["spec"][
        "template"
    ]["spec"]
    assert "tool-results" not in {v["name"] for v in disabled_pod["volumes"]}
    pod = render()["Deployment"]["spec"]["template"]["spec"]
    volume = next(v for v in pod["volumes"] if v["name"] == "tool-results")
    assert volume["emptyDir"] == {"sizeLimit": "1Gi"}
    env = {e["name"]: e.get("value") for e in pod["containers"][0]["env"]}
    assert env["AGENT_RUNTIME_V2_ANALYSIS__ROOT"] == "/var/lib/guild-runtime/tool-results/private"
    assert env["AGENT_RUNTIME_V2_ANALYSIS__ENABLED"] == "true"
