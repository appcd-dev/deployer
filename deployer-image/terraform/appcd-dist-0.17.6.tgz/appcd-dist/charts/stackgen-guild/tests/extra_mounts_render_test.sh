#!/usr/bin/env bash
# Renders stackgen-guild with inline extraMounts and asserts config.yaml /
# extra-mount manifests keep YAML keys on their own lines (no {{- chomp glue).
set -euo pipefail

chart_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
tmp="$(mktemp)"
trap 'rm -f "$tmp" "$tmp.err" "$tmp.cfg" "$tmp.em"' EXIT

assert_contains() {
  local haystack="$1"
  local needle="$2"
  if ! grep -F --quiet -- "$needle" <<<"$haystack"; then
    echo "expected rendered chart to contain: $needle" >&2
    return 1
  fi
}

assert_not_contains() {
  local haystack="$1"
  local needle="$2"
  if grep -F --quiet -- "$needle" <<<"$haystack"; then
    echo "expected rendered chart not to contain: $needle" >&2
    return 1
  fi
}

# Fail if classic left-chomp glue patterns appear (same-line key mashups).
assert_no_chomp_glue() {
  local haystack="$1"
  local label="$2"
  if grep -E --quiet -- 'cpu_request: "[^"]+"[[:blank:]]+volumes:' <<<"$haystack"; then
    echo "$label: cpu_request glued to volumes on one line" >&2
    return 1
  fi
  if grep -E --quiet -- 'volumes:[[:blank:]]*-' <<<"$haystack"; then
    echo "$label: volumes: glued to list item" >&2
    return 1
  fi
  if grep -E --quiet -- '- name: [^[:space:]]+[[:blank:]]+(configMap|secret):' <<<"$haystack"; then
    echo "$label: volume name glued to configMap/secret" >&2
    return 1
  fi
  if grep -E --quiet -- 'readOnly: true-' <<<"$haystack"; then
    echo "$label: readOnly glued to next list item" >&2
    return 1
  fi
  if grep -E --quiet -- 'value: "[^"]*"-' <<<"$haystack"; then
    echo "$label: env value glued to next token" >&2
    return 1
  fi
  if grep -E --quiet -- 'extra-mount: "[^"]+"(data|stringData|binaryData):' <<<"$haystack"; then
    echo "$label: extra-mount label glued to data/stringData" >&2
    return 1
  fi
  if grep -E --quiet -- 'type: "[^"]+"(stringData|data):' <<<"$haystack"; then
    echo "$label: Secret type glued to stringData/data" >&2
    return 1
  fi
}

# Parse agent_runtime.kubernetes.integrations from rendered guild ConfigMap.
extract_and_parse_integrations() {
  local rendered="$1"
  python3 - "$rendered" <<'PY'
import re, sys, yaml
text = open(sys.argv[1]).read()
# Find config.yaml literal block in the guild ConfigMap.
m = re.search(r"(?m)^  config\.yaml: \|$", text)
if not m:
    sys.exit("config.yaml block not found")
lines = []
for line in text[m.end()+1:].splitlines():
    if line.startswith("    "):
        lines.append(line[4:])
        continue
    if line.startswith("  ") and not line.startswith("    "):
        break
    if line.startswith("---"):
        break
cfg = yaml.safe_load("\n".join(lines))
integ = cfg["agent_runtime"]["kubernetes"]["integrations"]
vols = integ.get("volumes") or []
mounts = integ.get("volume_mounts") or []
env = integ.get("env") or []
assert len(vols) >= 2, f"expected >=2 volumes, got {len(vols)}"
assert len(mounts) >= 2, f"expected >=2 mounts, got {len(mounts)}"
assert len(env) >= 3, f"expected >=3 env entries, got {len(env)}"
names = [v["name"] for v in vols]
assert "acme-config" in names and "acme-secret" in names, names
assert any(e["name"] == "ACME_CONFIG_PATH" for e in env)
assert any(e["name"] == "ACME_APP_CONF" for e in env)
assert any(e["name"] == "ACME_API_TOKEN" for e in env)
# Each volume must have exactly one of configMap/secret as a nested map.
for v in vols:
    has_cm = isinstance(v.get("configMap"), dict)
    has_sec = isinstance(v.get("secret"), dict)
    assert has_cm ^ has_sec, v
print("integrations yaml ok", len(vols), len(mounts), len(env))
PY
}

cat >"$tmp" <<'EOF'
config:
  agentRuntime:
    kubernetes:
      enabled: true
      integrations:
        enabled: true
extraMounts:
  - name: acme-config
    mountPath: /etc/acme/app.conf
    subPath: app.conf
    key: app.conf
    env:
      - ACME_CONFIG_PATH
      - ACME_APP_CONF
    configMap:
      name: acme-config
      data:
        app.conf: |
          hello world
  - name: acme-secret
    mountPath: /etc/acme/api-token
    subPath: api-token
    key: api-token
    env:
      - ACME_API_TOKEN
    secret:
      name: acme-secret
      stringData:
        api-token: s3cret
EOF

cfg="$(helm template guild "$chart_dir" -f "$tmp" --namespace appcd-alpha -s templates/configmap.yaml)"
printf '%s\n' "$cfg" >"$tmp.cfg"
assert_no_chomp_glue "$cfg" "configmap"
assert_contains "$cfg" 'cpu_request: "100m"'
assert_contains "$cfg" 'volumes:'
assert_contains "$cfg" 'name: acme-config'
assert_contains "$cfg" 'name: acme-secret'
assert_contains "$cfg" 'mountPath: /etc/acme/app.conf'
assert_contains "$cfg" 'name: ACME_CONFIG_PATH'
assert_contains "$cfg" 'name: ACME_APP_CONF'
assert_contains "$cfg" 'name: ACME_API_TOKEN'
extract_and_parse_integrations "$tmp.cfg"

mounts="$(helm template guild "$chart_dir" -f "$tmp" --namespace appcd-alpha -s templates/extra-mounts.yaml)"
printf '%s\n' "$mounts" >"$tmp.em"
assert_no_chomp_glue "$mounts" "extra-mounts"
assert_contains "$mounts" 'kind: ConfigMap'
assert_contains "$mounts" 'kind: Secret'
assert_contains "$mounts" 'stringData:'
# Labels and data keys must be on separate lines.
assert_contains "$mounts" 'guild.stackgen.com/extra-mount: "acme-config"'
assert_contains "$mounts" 'guild.stackgen.com/extra-mount: "acme-secret"'

# Chart-root volumes must not appear under integrations.
cat >"$tmp" <<'EOF'
volumes:
  - name: guild-only-empty
    emptyDir: {}
volumeMounts:
  - name: guild-only-empty
    mountPath: /var/guild-only
config:
  agentRuntime:
    kubernetes:
      enabled: true
      integrations:
        enabled: true
EOF
cfg="$(helm template guild "$chart_dir" -f "$tmp" --namespace appcd-alpha -s templates/configmap.yaml)"
assert_not_contains "$cfg" 'guild-only-empty'

# integrations.enabled: false must not copy extraMounts into a different sandbox NS.
cat >"$tmp" <<'EOF'
mcpGateway:
  enabled: true
config:
  agentRuntime:
    kubernetes:
      enabled: false
      integrations:
        enabled: false
        namespace: guild-sandbox-test
extraMounts:
  - name: acme-config
    mountPath: /etc/acme/app.conf
    key: app.conf
    configMap:
      name: acme-config
      data:
        app.conf: hello
EOF
mounts="$(helm template guild "$chart_dir" -f "$tmp" --namespace appcd-alpha -s templates/extra-mounts.yaml)"
assert_not_contains "$mounts" 'namespace: guild-sandbox-test'
assert_contains "$mounts" 'namespace: appcd-alpha'

# kubernetes.enabled false but mcp-gateway on still copies into sandbox.
cat >"$tmp" <<'EOF'
mcpGateway:
  enabled: true
config:
  agentRuntime:
    kubernetes:
      enabled: false
      integrations:
        enabled: true
        namespace: guild-sandbox-test
extraMounts:
  - name: acme-config
    mountPath: /etc/acme/app.conf
    key: app.conf
    configMap:
      name: acme-config
      data:
        app.conf: hello
EOF
mounts="$(helm template guild "$chart_dir" -f "$tmp" --namespace appcd-alpha -s templates/extra-mounts.yaml)"
assert_contains "$mounts" 'namespace: guild-sandbox-test'

# Reserved volume names fail at helm time.
if helm template guild "$chart_dir" --namespace appcd-alpha -f /dev/stdin >/dev/null 2>"$tmp.err" <<'EOF'
extraMounts:
  - name: tmp
    mountPath: /etc/data/x
    key: x
    configMap:
      name: x
      data:
        x: y
EOF
then
  echo "expected reserved name tmp to fail helm template" >&2
  exit 1
fi
grep -q 'built-in volume' "$tmp.err" || { echo "expected reserved-name fail message"; cat "$tmp.err"; exit 1; }

# Missing inline key fails at helm time.
if helm template guild "$chart_dir" --namespace appcd-alpha -f /dev/stdin >/dev/null 2>"$tmp.err" <<'EOF'
extraMounts:
  - name: acme-config
    mountPath: /etc/acme/app.conf
    key: missing.txt
    configMap:
      name: acme-config
      data:
        app.conf: hello
EOF
then
  echo "expected missing key to fail helm template" >&2
  exit 1
fi
grep -q 'not found in configMap' "$tmp.err" || { echo "expected key validation fail message"; cat "$tmp.err"; exit 1; }

echo "extra_mounts_render_test: ok"
