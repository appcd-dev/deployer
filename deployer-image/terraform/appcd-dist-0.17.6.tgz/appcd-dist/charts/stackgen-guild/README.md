# stackgen-guild Helm Chart

Deploys the StackGen Guild platform: **guild** (orchestrator + API + Temporal workers), **gateway** (omnichannel), **mcp-gateway** (agent integration MCP), **agent-runtime-v2** (agents v2 turn worker), and **ui** (React console).

## agents v2 runtime

`agentRuntimeV2.enabled` defaults to `false`. A default install renders no runtime
objects. Guild gets `GUILD_AGENT_RUNTIME_V2_ENABLED="false"`, so it keeps every turn
on the Go runtime, whatever the `aios.agentsv2.runtime.enabled` flag says. Turn the
runtime on per environment. Guild then gets `GUILD_AGENT_RUNTIME_V2_ENABLED="true"`,
and the flag decides which turns go to agents v2.

In appcd-dist, under `stackgen-guild:`:

```yaml
agentRuntimeV2:
  enabled: true
  databaseCredentials:
    existingSecret: appcd-secrets
  # Optional: scrape the runtime. Off by default, like Guild.
  serviceMonitor:
    enabled: true
```

When enabled, two replicas consume turns over NATS, using the shared `-envvars`
ConfigMap for NATS and Vault. The image is
`ghcr.io/appcd-dev/stackgen-guild-agent-runtime-v2`. An empty
`agentRuntimeV2.image.tag` takes Guild's tag, because CI tags both images the
same way. Set the tag only to pin the runtime to a different build.

The worker mounts Guild's blob-storage claim at the same path and stores skills
and workspaces in `agentRuntimeV2.sharedRootSubdir` (default `agent-runtime-v2`).
It runs as uid/gid 1001, with `/tmp` writable and a read-only root filesystem.
When blob storage is disabled, each pod uses ephemeral storage.

History persistence is on whenever the runtime is. It reads the database host,
port, user and password from `databaseCredentials.existingSecret`, with the same
`rds_*` keys as context-graph-svc. The chart creates no Secret. The database name
is `databaseCredentials.database`, or `config.database.name` when that is empty.
The SSL mode comes from `global.database.sslMode` (default `disable`). Rendering
fails when the runtime is enabled without the Secret name.

Migrations run once per install or upgrade, in a `pre-install,pre-upgrade` hook Job
named `<release>-agent-runtime-v2-migrate`. A failed migration fails the release
before new pods start. `agentRuntimeV2.migrations.enabled: false` skips the Job.

Health (`/healthz`) uses port 8083. Prometheus metrics (`/metrics`) have their own
port, `agentRuntimeV2.metrics.port` (default 9091). `agentRuntimeV2.serviceMonitor.enabled`
adds the scrape annotations to the Service and, when the cluster has the CRD, a
ServiceMonitor. Guild's own `serviceMonitor` setting no longer affects the runtime.
The liveness probe is a TCP check, so a short database outage does not restart pods.

`agentRuntimeV2.turnTimeoutSeconds` limits each turn. It defaults to 3600 seconds,
which is also the most the runtime accepts. `agentRuntimeV2.maxConcurrentTurns`
(default 50) is how many turns one replica runs at once. A waiting turn holds no
database connection, so `agentRuntimeV2.persistence.poolSize` does not need to match it.

Traces use the existing documented cluster collector by default. Override its
address for other clusters:

```yaml
agentRuntimeV2:
  observability:
    otlpEndpoint: otel-collector.devopsnow.svc.cluster.local:4317
    insecure: true
    traces:
      enabled: true
      sampleRatio: 1.0
```

Logs are JSON on stdout. OTLP logs remain off because Observe already collects
stdout. The runtime rejects enabled OTLP signals without an endpoint at startup.
Prompt and response capture remain off. Enabling traces does not enable content
capture. Operators can explicitly disable traces or change the sampling ratio.

`providerSecrets` maps Kubernetes secret keys to prefixed provider environment
variables; optional defaults reference `openai-secret` and `google-gemini`.
Each entry declares `secret`, `key`, `env`, and `optional`; no key values belong
in Helm values. `make helm/test` renders the default and enabled configurations,
scraping, migrations, storage and secrets, and runs Helm lint on both.

Stateless server model requests use the runtime's private HTTP API. Connect
Guild to it without creating another credential:

```yaml
agentRuntimeV2:
  directAPI:
    enabled: true
```

Guild forwards the existing platform identity headers and request actor. Python
passes that actor to the model service without a separate password check or new
identity validation. Existing client authentication and provider credentials are
unchanged. The chart supplies `GUILD_AGENT_RUNTIME_V2_HTTP_URL` when this switch
and the runtime deployment are enabled; otherwise Guild has no direct-model URL.
The Python endpoint itself does not perform authentication.

Upgrade Guild, Python, and the chart together: older images still require the
service token. `directAPI.secretName`, `directAPI.secretKey`, and both processes'
`*_DIRECT_API_TOKEN` settings have been removed. No new network policy or CNI
configuration is introduced by this change.

## Prerequisites

- Helm 3.x
- A Kubernetes cluster with the target namespace created
- `ghcr-pkg` image-pull secret in the namespace

## Values Files

| File | Committed | Purpose |
|---|---|---|
| `values.yaml` | Yes | Chart defaults. The agents v2 runtime is off. Enabling it needs `agentRuntimeV2.databaseCredentials.existingSecret`. `mcpGateway.enabled: false` skips the mcp-gateway Deployment/Service/SA. |
| `values-genie.yaml` | Yes | Genie-namespace base config (images, resources, ingress, infra endpoints). **Contains no secrets.** |
| `dev.yaml` | **No** (git-ignored) | Local secret overlay — database URLs, auth tokens, Langfuse keys |
| `dev.yaml.example` | Yes | Template for `dev.yaml` with placeholder values |

### Quick Start

```bash
# 1. Copy the example and fill in your credentials
cp iac/helm/stackgen-guild/dev.yaml.example iac/helm/stackgen-guild/dev.yaml
#    Edit dev.yaml with real values

# 2. Build chart dependencies (NATS, etc.)
helm dependency build iac/helm/stackgen-guild

# 3. Deploy to genie namespace
# --dry-run=client \
helm upgrade --debug --install --wait \
  stackgen-guild . \
  -n genie --create-namespace \
  -f values-genie.yaml \
  -f dev.yaml
```

Helm merges values files left-to-right, so `dev.yaml` overrides the placeholders in `values-genie.yaml`.

## Secret Overlay (`dev.yaml`)

`dev.yaml` is **git-ignored** and supplies all sensitive values. Copy `dev.yaml.example` to get started. It contains:

| Section | Keys | Description |
|---|---|---|
| `guild.env` / `gateway.env` | `GUILD_DATABASE_URL`, `GUILD_DATABASE_READ_REPLICA_URL` | Postgres connection strings |
| `config.database.pool` | `guild` / `gateway` maxOpenConns, maxIdleConns, lifetimes | Per-process SQL pool caps (fleet budget in Capacity section) |
| `ingress.auth` | `allowedIPs`, `basicAuthEncoded`, `bearerTokens` | Ingress authentication |
| `config.langfuse` | `secretKey`, `publicKey`, `host`, `sendInfo` | Langfuse credentials + how much I/O to send (`full` / `omit` / `pii_redact`) |
| `config.pii` | `customRegexes`, `safeRegexes`, `sensitiveKeys`, … | Global PII scanner; used by LLM redaction and `sendInfo: pii_redact` |
| `config.featureFlags` | fully-qualified `aios.*` keys → bool | Static feature-flag overrides when Unleash is missing or unusable; non-empty replaces Unleash for the process |
| `guild.env` / `guild-secrets` | `GUILD_DATA_ENCRYPTION_KEY` | AES key for remote-runner JIT OAuth at rest (Mode 3); `openssl rand -base64 32` |

## Langfuse Configuration

Langfuse tracing is controlled by `config.langfuse`. When enabled, a K8s Secret is created and injected via `envFrom` into guild and gateway pods.

How much observation/trace I/O to send is controlled by `config.langfuse.sendInfo` (`full` | `omit` | `pii_redact`). The chart maps that to Genie env `LANGFUSE_OBSERVATION_BODIES` on the **guild** pod only when `config.langfuse.enabled` is true (`full` → `off`, `omit` → `omit`, `pii_redact` → `pii_redact`; anything else → `off`). If `guild.env` already sets `LANGFUSE_OBSERVATION_BODIES`, that value wins and the chart does not emit a duplicate. Default `full` keeps watch/debug useful.

```yaml
config:
  langfuse:
    enabled: true
    sendInfo: "pii_redact" # or omit / full
  # Optional: extra deny/allow patterns for pii_redact (and all other PII paths)
  pii:
    customRegexes:
      - name: employee_id
        pattern: '\bEMP-[0-9]{6}\b'
    safeRegexes:
      - name: grafana_uid
        pattern: '^[A-Za-z0-9]{8,16}$'
```

Matches become `[HIDDEN:<name>]`. Built-in entropy/sensitive-key rules still apply. Empty lists omit the `pii:` block so Genie defaults stay. If you set `safeRegexes`, that list replaces Genie’s default allowlist (Guild still appends tool-name / kebab / sha256 safe patterns at startup).

## Static feature flags

Guild already supports static overrides in `config.yaml` (`feature_flags:` → `seedStaticFeatureFlags`). The chart exposes that as `config.featureFlags`.

Use this when the cluster has no usable Unleash (for example in-cluster Unleash with `UNLEASH_API_KEY=dummy`). Leave the map empty when cloud or in-cluster Unleash is authoritative.

```yaml
config:
  featureFlags:
    "aios.guild.memory_learning.enabled": true
    "aios.guild.operational_analytics.enabled": true
```

A non-empty map replaces the Unleash client for the Guild process. Flags not listed evaluate as off. Quote dotted keys so Helm keeps them as flat map keys.

### Option A: Credentials in `dev.yaml`

```yaml
# dev.yaml
config:
  langfuse:
    secretKey: "sk-lf-..."
    publicKey: "pk-lf-..."
    host: "https://langfuse.cloud.stackgen.com"
```

The base file (`values-genie.yaml`) sets `config.langfuse.enabled: true`; `dev.yaml` fills in the actual keys.

### Option B: Pre-existing K8s Secret

If credentials are managed externally (e.g. Vault, ExternalSecrets):

```yaml
config:
  langfuse:
    enabled: true
    existingSecret: "my-langfuse-secret"
```

The Secret must contain keys: `LANGFUSE_SECRET_KEY`, `LANGFUSE_PUBLIC_KEY`, `LANGFUSE_HOST`.

## Temporal Worker Graceful Shutdown

Long-running workflow stages (`ProcessStage`) survive rolling deploys when the guild worker drains in-flight activities before exit.

| Setting | Location | Default |
|---|---|---|
| `config.workerConcurrency.workerStopTimeout` | `config.yaml` / Helm values | `10m` |
| `guild.terminationGracePeriodSeconds` | Deployment pod spec | `660` (11m) |
| `guild.lifecycle.preStop` | Deployment container | `sleep 5` (endpoint drain) |
| `GUILD_WORKER_STOP_TIMEOUT` | Env override (optional) | — |

**Rule:** `terminationGracePeriodSeconds` ≥ `workerStopTimeout` + ~60s (HTTP API shutdown + gRPC drain).

For multi-replica deploys, keep `guild.kedaAutoscaling.minReplicas: 2` so Temporal can retry canceled activities on healthy pods while others drain.

**Prometheus triggers** (`guild.kedaAutoscaling.prometheus`): enable alongside Temporal when chat load is LLM-bound and the task-queue backlog stays at zero while activity slots or `guild_executions_active` rise. Defaults target in-cluster `kube-prometheus-stack-prometheus`. For remote Mimir/Observe, set `serverAddress` to the Prometheus query base (e.g. `https://…/prometheus`) and enable `prometheus.authentication`. Secret location depends on `authentication.kind`:

- `ClusterTriggerAuthentication` (default): `observe-metrics-keda` in the **keda** operator namespace (shared across releases on one cluster).
- `TriggerAuthentication`: same secret name in the **Helm release namespace** (each env owns its auth; use when two releases on one cluster must deploy independently).

Sync credentials via ExternalSecrets. Do not put them in Helm values.

### KEDA Prometheus cluster profiles

| Profile | When to use | Values overlay |
|---------|-------------|----------------|
| **in-cluster** | Cluster runs `kube-prometheus-stack` with a reachable Prometheus Service (e.g. developer-eks, dev.ai) | [`values-overrides/keda-prometheus-in-cluster.yaml`](values-overrides/keda-prometheus-in-cluster.yaml) |
| **observe-remote** | Metrics remote-written to Observe/Mimir only (e.g. community-cloud-eks) | [`values-overrides/keda-prometheus-observe-remote.yaml`](values-overrides/keda-prometheus-observe-remote.yaml) + appcd-dist `ops.externalSecrets.observeMetricsKeda: true` |

**Temporal namespace:** `config.temporal.namespace` must match the effective `guild.kedaAutoscaling.temporal.namespace` (defaults to the Helm release namespace). Helm fails at template time on mismatch when the app namespace is not the chart default `default`.

**Grafana:** Import [`iac/grafana/guild-apm-dashboard.json`](../../grafana/guild-apm-dashboard.json) — row **KEDA autoscaling** correlates replicas, HPA, activity slots, `guild_executions_active`, and `StartAgentChat` rate (see [`docs/Metrics.md`](../../docs/Metrics.md)).

**Capacity:** Before raising `maxReplicas`, enforce the Postgres fleet budget:

```
(guild_pods + gateway_pods) × config.database.pool.*.maxOpenConns
  ≤ 0.8 × RDS_max_connections − admin_headroom
```

Defaults: guild `maxOpenConns=20`, gateway `maxOpenConns=5` (see `config.database.pool`).
Example: RDS `max_connections=150` with guild pool 20 → at most ~6 total pods.
Prefer lowering per-pod pool or adding PgBouncer (**session** pooling — transaction mode breaks advisory locks) over raising RDS alone. Also model Qdrant throughput and LLM provider rate limits — scaling guild pods can exhaust the DB pool before CPU.


Guild uses an embedding provider (OpenAI by default) to vectorize skills, workflows, and uploaded documents into Qdrant for semantic search. Without this configuration, the Qdrant collection will remain empty and knowledge search tools won't return results.

### Required Environment Variables

| Variable | Description | Example |
|---|---|---|
| `VECTOR_STORE_PROVIDER` | Vector store backend | `qdrant` (set in `values-genie.yaml`) |
| `QDRANT_HOST` | Qdrant service address | `qdrant.genie.svc.cluster.local` (set in `values-genie.yaml`) |
| `QDRANT_COLLECTION_NAME` | Qdrant collection name | Defaults to `trpc_agent_documents` if unset |
| `EMBEDDING_PROVIDER` | Embedding model provider | `openai` |
| `OPENAI_API_KEY` | API key for embedding generation | `sk-...` (secret — set via `dev.yaml` or Vault) |

> [!IMPORTANT]
> `EMBEDDING_PROVIDER` and the corresponding API key (e.g. `OPENAI_API_KEY`) must be set on the **guild** pod for vectorization to work. Without these, workflow/skill/document vectorization silently no-ops.

### Configuration

`VECTOR_STORE_PROVIDER` and `QDRANT_HOST` are already set in `values-genie.yaml`. Add the embedding provider in your `dev.yaml`:

```yaml
# dev.yaml
guild:
  env:
    EMBEDDING_PROVIDER: "openai"
    # OPENAI_API_KEY is typically provided via envFromSecret or secrets.data
```

The `OPENAI_API_KEY` should be supplied via one of:

- **`secrets.data`** (Helm-managed K8s Secret):
  ```yaml
  secrets:
    create: true
    data:
      OPENAI_API_KEY: "sk-..."
  ```
- **`guild.envFromSecret`** (pre-existing K8s Secret):
  ```yaml
  guild:
    envFromSecret: "openai-secret"
  ```
- **Vault** (resolved at runtime via the secret provider)

### Verifying Vectorization

After deploying with the embedding provider configured:

1. Check guild pod logs for `"Vector store initialized"` with the correct host/collection
2. Create or update a workflow — logs should show `"Workflow skill vectorized"`
3. Query Qdrant: `curl http://localhost:6333/collections/trpc_agent_documents` (via port-forward) should show `points_count > 0`

## Observe / vmagent metrics scrape

StackGen Observe discovers targets via `prometheus.io/*` annotations on the **Service** (not ServiceMonitor CRDs alone). Enable scrape for guild, gateway, and mcp-gateway:

| Flag | Effect |
|---|---|
| `guild.serviceMonitor.enabled` | Annotates guild Service **and** gateway / mcp-gateway Services (those couple to this flag) |
| `gateway.serviceMonitor.enabled` | Annotates gateway Service (and creates ServiceMonitor CRD when Operator is present) |
| `mcpGateway.serviceMonitor.enabled` | Annotates mcp-gateway Service (and creates ServiceMonitor CRD when Operator is present) |
| `agentRuntimeV2.serviceMonitor.enabled` | Annotates the agents v2 runtime Service with its metrics port, 9091 (and creates ServiceMonitor CRD when Operator is present). Needs `agentRuntimeV2.enabled`. Not coupled to Guild's flag |

**Appcd-dist overlay** (recommended for alpha/stage):

```bash
helm upgrade appcd appcd-releases/appcd-dist -n appcd-alpha --reuse-values \
  -f iac/helm/stackgen-guild/values-overrides/observe-guild-metrics.yaml
```

See [`values-overrides/observe-guild-metrics.yaml`](values-overrides/observe-guild-metrics.yaml) and [`docs/Metrics.md`](../../../docs/Metrics.md) (Observe scrape checklist). Gateway metrics listen on container port **9091** (LLM router series); Service exposes metrics on **9091** after chart ≥ this change.

## Custom mounts (optional CA, certs, license files)

Pick by **who** needs the file.

| Approach | Scope |
| --- | --- |
| **Additional files** on the integration vault secret | That integration’s MCP sidecar only (prefer for a private Grafana CA) |
| chart-root `extraMounts` | Guild + gateway + all MCP sidecars |
| chart-root `volumes` / `volumeMounts` | Guild / gateway only |
| `config.agentRuntime.kubernetes.integrations.volumes` / `volumeMounts` / `env` | Sidecars only (object must already exist in the sandbox) |

### Additional files (per-integration)

On the Grafana (or other) credentials form, optional masked fields:

- **CA certificate** (`ca_bundle`) — PEM text
- **Additional files** (`additional_files`) — JSON array of `{key, path, env?, mode?}`

Paths must be under `/run/secrets/files/`. Example:

```json
[{"key":"ca_bundle","path":"/run/secrets/files/ca-bundle.crt","env":["SSL_CERT_FILE","CURL_CA_BUNDLE"]}]
```

File bodies stay out of `env.json`; only path env vars (like `SSL_CERT_FILE`) are
set on the container. Combined PEM rules still apply. This does **not** change
guild process trust — use `extraMounts` for that.

### Helm knobs

| Knob | Guild / gateway | MCP sidecars | Creates CM/Secret in sandbox |
| --- | --- | --- | --- |
| chart-root `extraMounts` | yes | yes | yes (inline or `existing*` lookup copy of the declared `key`) |
| chart-root `volumes` / `volumeMounts` | yes | no | no |
| `config.agentRuntime.kubernetes.integrations.volumes` / `volumeMounts` / `env` | no | yes | **no** — object must already exist in the sandbox namespace |

**Prefer `extraMounts`** when guild, gateway, and sidecars should share the same
ConfigMap/Secret file (corporate CA, license file, etc.). Helm builds (or copies)
the object into the release namespace and the integration sandbox, then expands
volumes, mounts, and env. No runtime sync.

**Guild/gateway only:** use chart-root `volumes` / `volumeMounts` (emptyDir,
projected, etc.). These are **not** written into sidecar config and are **not**
copied into the sandbox.

**Sidecars only:** leave `extraMounts` empty and set raw PodSpec under
integrations. Helm does **not** create or copy the ConfigMap/Secret; create it
in the sandbox namespace yourself (same name the volume references):

```yaml
# do NOT set chart-root extraMounts for this file
config:
  agentRuntime:
    kubernetes:
      integrations:
        volumes:
          - name: acme-config
            configMap:
              name: acme-config
              items:
                - key: app.conf
                  path: app.conf
          - name: acme-secret
            secret:
              secretName: acme-secret
              items:
                - key: api-token
                  path: api-token
        volumeMounts:
          - name: acme-config
            mountPath: /etc/acme/app.conf
            subPath: app.conf
            readOnly: true
          - name: acme-secret
            mountPath: /etc/acme/api-token
            subPath: api-token
            readOnly: true
        env:
          - name: ACME_CONFIG_PATH
            value: /etc/acme/app.conf
          - name: ACME_API_TOKEN_FILE
            value: /etc/acme/api-token
```

`existingConfigMap` / `existingSecret` (on `extraMounts`) copy **only the
declared `key`** into the sandbox. That value is still rendered into the Helm
release (and revision history). Prefer inline `configMap.data` with Sealed
Secrets / ESO when Helm history must not hold the material.

Reserved volume names (`secrets`, `tmp`, `home`, `config-volume`,
`guild-storage`, `aios-apps-catalog`) are rejected.

### Example: private CA / corporate trust PEM

Mount a **pre-combined** PEM (public roots + private CAs). `SSL_CERT_FILE`
replaces the image system trust store — do not mount only the corporate CA.

**Option A — existing ConfigMap** (create it first; `helm install` needs
cluster access so the chart can `lookup` and copy into the sandbox):

```bash
kubectl -n <guild-ns> create configmap corporate-trust \
  --from-file=ca-bundle.crt=/path/to/combined-ca-bundle.crt
```

```yaml
extraMounts:
  - name: corporate-ca
    mountPath: /etc/ssl/custom/ca-bundle.crt
    subPath: ca-bundle.crt
    readOnly: true
    key: ca-bundle.crt
    env:
      - SSL_CERT_FILE
      - CURL_CA_BUNDLE
      - REQUESTS_CA_BUNDLE
      - GIT_SSL_CAINFO
      - AWS_CA_BUNDLE
      - CLOUDSDK_CORE_CUSTOM_CA_CERTS_FILE
    existingConfigMap: corporate-trust
```

**Option B — inline data** (Helm creates the ConfigMap in both namespaces;
works with offline `helm template`):

```yaml
extraMounts:
  - name: corporate-ca
    mountPath: /etc/ssl/custom/ca-bundle.crt
    subPath: ca-bundle.crt
    readOnly: true
    key: ca-bundle.crt
    env:
      - SSL_CERT_FILE
      - CURL_CA_BUNDLE
      - REQUESTS_CA_BUNDLE
    configMap:
      name: corporate-trust
      data:
        ca-bundle.crt: |
          -----BEGIN CERTIFICATE-----
          ...
          -----END CERTIFICATE-----
```

Use `existingSecret` / `secret.stringData` the same way when policy requires a Secret.

Namespace-wide injection for pods that Guild does not create still needs a
cluster mutation policy (Kyverno / Gatekeeper) or similar.

## Architecture

```
values.yaml            (chart defaults, all features off)
  └─ values-genie.yaml (genie infra config, no secrets)
       └─ dev.yaml     (secret overlay, git-ignored)
```

Each layer only overrides what it needs. Non-secret config lives in committed files; credentials live in the local-only `dev.yaml`.

### Python runtime skill memory cache

`agentRuntimeV2.skillCache.refreshSeconds` (default 1800) refreshes active workspace
metadata in the background; only new or changed bodies are fetched. Zero requests a
fresh snapshot on every turn. A workspace unused for two intervals leaves memory and
loads again on its next turn. With zero, snapshots stay for the process lifetime.

No skill files are written to the artifact PVC. New pods hydrate once before execution.
Capabilities remain deferred. A failed refresh keeps serving the last complete snapshot
and retries within a minute. Only a workspace with no snapshot waits for Guild. Workspace files and durable tool
results keep their existing storage.
